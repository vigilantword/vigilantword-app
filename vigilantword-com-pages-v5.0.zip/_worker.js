const PRODUCTS = {
  "app": { name: "Vigilant Word app", price: "9.99" },
  "complete": { name: "The Complete Edition", price: "29.99", file: "vigilant-word-complete-edition.epub" },
  "old-testament": { name: "The Old Testament", price: "19.99", file: "vigilant-word-old-testament.epub" },
  "new-testament": { name: "The New Testament", price: "19.99", file: "vigilant-word-new-testament.epub" }
};
const ORIGINS = ["https://vigilantword.app", "https://www.vigilantword.app", "https://vigilantword.com", "https://www.vigilantword.com"];
const APP_URL = "https://vigilantword.app";
let keyCache = null;
const LINK_SECONDS = 7 * 24 * 60 * 60;
const MAX_DOWNLOADS = 15, MAX_NETWORKS = 6, MAX_DEVICES = 5;
const KEEP_PURCHASE = 400 * 24 * 60 * 60, KEEP_DEVICE = 90 * 24 * 60 * 60;
const GOOD = ["COMPLETED", "PARTIALLY_REFUNDED"];
const enc = new TextEncoder();
const SAFE = { "X-Content-Type-Options": "nosniff", "Referrer-Policy": "no-referrer" };
let tokenCache = { t: "", x: 0 };

function cors(request) {
  const o = request.headers.get("Origin");
  if (!ORIGINS.includes(o)) return {};
  return { "Access-Control-Allow-Origin": o, "Vary": "Origin", "Access-Control-Allow-Methods": "GET,POST,OPTIONS", "Access-Control-Allow-Headers": "Content-Type,X-Admin-Key", "Access-Control-Max-Age": "86400" };
}

function json(request, body, status = 200) {
  return new Response(JSON.stringify(body), { status, headers: { "Content-Type": "application/json", "Cache-Control": "no-store", ...SAFE, ...cors(request) } });
}

function originOk(request, url) {
  const o = request.headers.get("Origin");
  return !o || ORIGINS.includes(o) || o === url.origin;
}

function b64url(buf) {
  const bytes = new Uint8Array(buf);
  let s = "";
  for (let i = 0; i < bytes.length; i++) s += String.fromCharCode(bytes[i]);
  return btoa(s).replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
}

function unb64url(s) {
  s = s.replace(/-/g, "+").replace(/_/g, "/");
  while (s.length % 4) s += "=";
  return Uint8Array.from(atob(s), (c) => c.charCodeAt(0));
}

function shortIp(ip) {
  if (!ip) return "";
  if (ip.indexOf(":") >= 0) return ip.split(":").filter(Boolean).slice(0, 3).join(":") + "::";
  const p = ip.split(".");
  return p.length === 4 ? p.slice(0, 3).join(".") + ".0" : "";
}

async function kget(env, key) {
  try { return env.RECORDS ? await env.RECORDS.get(key, "json") : null; } catch (e) { return null; }
}
async function kput(env, key, value, ttl) {
  try { if (env.RECORDS) await env.RECORDS.put(key, JSON.stringify(value), ttl ? { expirationTtl: Math.max(60, Math.floor(ttl)) } : undefined); } catch (e) {}
}

async function hit(env, key, max, ttl) {
  if (!env.RECORDS) return true;
  const rec = (await kget(env, key)) || { n: 0 };
  if (rec.n >= max) return false;
  rec.n++;
  await kput(env, key, rec, ttl);
  return true;
}

function paypalBase(env) {
  return env.PAYPAL_ENV === "live" ? "https://api-m.paypal.com" : "https://api-m.sandbox.paypal.com";
}

async function accessToken(env) {
  if (tokenCache.t && tokenCache.x > Date.now()) return tokenCache.t;
  const r = await fetch(paypalBase(env) + "/v1/oauth2/token", {
    method: "POST",
    headers: { Authorization: "Basic " + btoa(env.PAYPAL_CLIENT_ID + ":" + env.PAYPAL_CLIENT_SECRET), "Content-Type": "application/x-www-form-urlencoded" },
    body: "grant_type=client_credentials"
  });
  if (!r.ok) throw new Error("paypal auth " + r.status);
  const d = await r.json();
  tokenCache = { t: d.access_token, x: Date.now() + Math.max(60, (d.expires_in || 300) - 60) * 1000 };
  return d.access_token;
}

function paidCapture(order, product) {
  const pu = order && order.purchase_units && order.purchase_units[0];
  const cap = pu && pu.payments && pu.payments.captures && pu.payments.captures[0];
  return !!(order && order.status === "COMPLETED" && pu && pu.reference_id === product &&
    cap && cap.status === "COMPLETED" && cap.amount.currency_code === "USD" && cap.amount.value === PRODUCTS[product].price);
}

async function paymentOk(env, orderId) {
  const cached = await kget(env, "pay:" + orderId);
  if (cached && cached.t > Date.now() - 3600000) return cached.ok;
  let ok = true;
  try {
    const h = { Authorization: "Bearer " + (await accessToken(env)) };
    const o = await fetch(paypalBase(env) + "/v2/checkout/orders/" + orderId, { headers: h });
    if (o.ok) {
      const od = await o.json();
      const cap = od.purchase_units && od.purchase_units[0] && od.purchase_units[0].payments && od.purchase_units[0].payments.captures && od.purchase_units[0].payments.captures[0];
      if (cap) {
        const c = await fetch(paypalBase(env) + "/v2/payments/captures/" + cap.id, { headers: h });
        ok = GOOD.includes(c.ok ? (await c.json()).status : cap.status);
      }
    }
  } catch (e) { ok = true; }
  await kput(env, "pay:" + orderId, { ok, t: Date.now() }, 7200);
  return ok;
}

async function downloadKey(env) {
  return crypto.subtle.importKey("raw", enc.encode(env.PAYPAL_CLIENT_SECRET + "|download"), { name: "HMAC", hash: "SHA-256" }, false, ["sign"]);
}

async function downloadSig(env, payload) {
  return b64url(await crypto.subtle.sign("HMAC", await downloadKey(env), enc.encode(payload)));
}

async function makeDownloadToken(env, orderId, product) {
  const payload = orderId + "." + product + "." + (Math.floor(Date.now() / 1000) + LINK_SECONDS) + "." + randomId(8);
  return btoa(payload).replace(/=+$/, "") + "." + (await downloadSig(env, payload));
}

async function readDownloadToken(env, token, product) {
  const [body, sig] = String(token || "").split(".");
  if (!body || !sig) return null;
  let payload;
  try { payload = atob(body + "=".repeat((4 - (body.length % 4)) % 4)); } catch (e) { return null; }
  const parts = payload.split(".");
  if (parts.length !== 4 || parts[1] !== product || Number(parts[2]) < Math.floor(Date.now() / 1000)) return null;
  return (await downloadSig(env, payload)) === sig ? { orderId: parts[0], expiry: Number(parts[2]), nonce: parts[3] } : null;
}

async function licenseKeys(env) {
  if (keyCache) return keyCache;
  if (!env.RECORDS) throw new Error("records store not connected");
  let rec = await env.RECORDS.get("lic:keys", "json");
  if (!rec) {
    const pair = await crypto.subtle.generateKey({ name: "ECDSA", namedCurve: "P-256" }, true, ["sign", "verify"]);
    rec = { priv: b64url(await crypto.subtle.exportKey("pkcs8", pair.privateKey)), pub: b64url(await crypto.subtle.exportKey("raw", pair.publicKey)) };
    await env.RECORDS.put("lic:keys", JSON.stringify(rec));
    rec = (await env.RECORDS.get("lic:keys", "json")) || rec;
  }
  keyCache = rec;
  return rec;
}

async function mintLicense(env, type, id, name) {
  const keys = await licenseKeys(env);
  const key = await crypto.subtle.importKey("pkcs8", unb64url(keys.priv), { name: "ECDSA", namedCurve: "P-256" }, false, ["sign"]);
  const payload = { t: type, id, iat: Math.floor(Date.now() / 1000) };
  if (name) payload.n = name;
  const body = "VW1." + b64url(enc.encode(JSON.stringify(payload)));
  return body + "." + b64url(await crypto.subtle.sign({ name: "ECDSA", hash: "SHA-256" }, key, enc.encode(body)));
}

async function readLicense(env, token) {
  const m = /^VW1\.([\w-]+)\.([\w-]+)$/.exec(String(token || ""));
  if (!m) return null;
  try {
    const keys = await licenseKeys(env);
    const key = await crypto.subtle.importKey("raw", unb64url(keys.pub), { name: "ECDSA", namedCurve: "P-256" }, false, ["verify"]);
    if (!(await crypto.subtle.verify({ name: "ECDSA", hash: "SHA-256" }, key, unb64url(m[2]), enc.encode("VW1." + m[1])))) return null;
    const p = JSON.parse(new TextDecoder().decode(unb64url(m[1])));
    return p && (p.t === "f" || p.t === "g") && p.id ? p : null;
  } catch (e) { return null; }
}

function randomId(n) {
  const letters = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  return Array.from(crypto.getRandomValues(new Uint8Array(n)), (x) => letters[x % letters.length]).join("");
}

function sameText(a, b) {
  if (a.length !== b.length) return false;
  let d = 0;
  for (let i = 0; i < a.length; i++) d |= a.charCodeAt(i) ^ b.charCodeAt(i);
  return d === 0;
}

async function adminCheck(request, env, net) {
  const r = env.RECORDS ? await kget(env, "rl:adm:" + net) : null;
  if (r && r.n >= 8) return 429;
  const k = request.headers.get("X-Admin-Key") || "";
  if (env.ADMIN_KEY && sameText(k, env.ADMIN_KEY)) return 0;
  await hit(env, "rl:adm:" + net, 99, 900);
  return 401;
}

async function findPayment(env, id) {
  const h = { Authorization: "Bearer " + (await accessToken(env)) };
  const base = paypalBase(env);
  let r = await fetch(base + "/v2/payments/captures/" + id, { headers: h });
  if (r.ok) {
    const c = await r.json();
    const p = PRODUCTS[c.custom_id];
    if (!p || !GOOD.includes(c.status) || !c.amount || c.amount.currency_code !== "USD" || c.amount.value !== p.price) return null;
    const rel = c.supplementary_data && c.supplementary_data.related_ids;
    return { product: c.custom_id, orderId: (rel && rel.order_id) || c.id };
  }
  r = await fetch(base + "/v2/checkout/orders/" + id, { headers: h });
  if (!r.ok) return null;
  const o = await r.json();
  const pu = o.purchase_units && o.purchase_units[0];
  const cap = pu && pu.payments && pu.payments.captures && pu.payments.captures[0];
  const p = pu && PRODUCTS[pu.reference_id];
  if (!p || o.status !== "COMPLETED" || !cap || !GOOD.includes(cap.status) || cap.amount.currency_code !== "USD" || cap.amount.value !== p.price) return null;
  return { product: pu.reference_id, orderId: o.id };
}

const ADMIN_PAGE = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="robots" content="noindex"><title>Vigilant Word · admin</title>
<style>body{margin:0;background:#f6f1e4;color:#1b2340;font:17px/1.5 Georgia,serif}main{max-width:560px;margin:0 auto;padding:24px 18px 48px}h1{margin:0 0 4px}h2{margin:34px 0 6px;font-size:1.2rem}label{display:block;margin:14px 0 4px;font-weight:700}input,textarea{width:100%;box-sizing:border-box;font:inherit;padding:11px;border:1.5px solid #ddd2b2;border-radius:8px;background:#fffdf4}button{font:inherit;font-weight:700;padding:11px 16px;margin:12px 8px 0 0;border:0;border-radius:8px;background:#c9a86a;color:#231a04}button.alt{background:#e7dfc8}p.msg{min-height:1.4em;color:#b01e24;margin:8px 0}table{width:100%;border-collapse:collapse;font-size:.85rem;margin-top:10px}td,th{text-align:left;padding:5px 4px;border-bottom:1px solid #ddd2b2;word-break:break-all}</style></head><body><main>
<h1>Vigilant Word admin</h1><p>Private. Anyone with the admin key can use this page.</p>
<label for="k">Admin key</label><input id="k" type="password" autocomplete="current-password">
<h2>Gift link</h2><p>A free, permanent unlock link for the app. It keeps working after every update.</p>
<label for="n">Who is it for? (optional)</label><input id="n" maxlength="24" placeholder="e.g. Pastor Mike">
<button id="go" type="button">Create gift link</button>
<textarea id="out" rows="4" readonly hidden></textarea><div id="act" hidden><button id="copy" type="button">Copy</button><button id="share" type="button">Share…</button></div>
<h2>Manage a code</h2><p>Paste a gift link, a code, or its ID (starts with G- for gifts, or a PayPal order number).</p>
<input id="lid" placeholder="Link, code or ID"><button id="rev" type="button">Block</button><button id="unrev" class="alt" type="button">Allow again</button><button id="rst" class="alt" type="button">Reset devices</button>
<h2>App signing key</h2><p>The public half of the signing key. It's safe to share; the private half never leaves Cloudflare.</p><button id="pub" type="button" class="alt">Show public key</button><textarea id="pubout" rows="2" readonly hidden></textarea>
<h2>Recent purchases</h2><button id="load" type="button" class="alt">Show the last 25</button><table id="tbl" hidden><thead><tr><th>When</th><th>What</th><th>Country</th><th>Order</th></tr></thead><tbody></tbody></table>
<p class="msg" id="msg" role="status"></p>
<script>
var $=function(i){return document.getElementById(i)},msg=$("msg"),base=location.href.replace(/admin\/?(\?.*)?$/,"");
try{$("k").value=sessionStorage.getItem("vwk")||""}catch(e){}
function call(path,body,method){return fetch(base+path,{method:method||"POST",headers:{"Content-Type":"application/json","X-Admin-Key":$("k").value},body:body?JSON.stringify(body):undefined}).then(function(r){return r.json().then(function(d){if(r.ok){try{sessionStorage.setItem("vwk",$("k").value)}catch(e){}}else{throw new Error(r.status===401?"That admin key is not right.":r.status===429?"Too many wrong tries. Wait 15 minutes.":"Something went wrong.")}return d})})}
function fail(e){msg.textContent=e&&e.message?e.message:"Could not reach the server."}
function idOf(v){v=v.trim();var m=/VW1\.([\w-]+)\./.exec(v);if(m){try{return JSON.parse(atob(m[1].replace(/-/g,"+").replace(/_/g,"/"))).id}catch(e){}}return v}
$("go").onclick=function(){msg.textContent="Working…";$("out").hidden=true;$("act").hidden=true;call("mint",{name:$("n").value}).then(function(d){msg.textContent="Ready — "+d.id;$("out").value=d.link;$("out").hidden=false;$("act").hidden=false}).catch(fail)};
$("copy").onclick=function(){$("out").select();(navigator.clipboard?navigator.clipboard.writeText($("out").value):Promise.reject()).then(function(){msg.textContent="Copied."},function(){document.execCommand("copy");msg.textContent="Copied."})};
$("share").onclick=function(){if(navigator.share)navigator.share({title:"Vigilant Word",text:"Your free copy of the Vigilant Word app:",url:$("out").value});else msg.textContent="Sharing isn't available here — tap Copy."};
function act(path,body,ok){var id=idOf($("lid").value);if(!id){msg.textContent="Enter a link, code or ID first.";return}msg.textContent="Working…";call(path,Object.assign({id:id},body)).then(function(){msg.textContent=ok+" ("+id+")"}).catch(fail)}
$("pub").onclick=function(){msg.textContent="Working…";fetch(base+"admin/pubkey",{headers:{"X-Admin-Key":$("k").value}}).then(function(r){return r.json().then(function(d){if(!r.ok)throw new Error("Not allowed — check the admin key.");$("pubout").value=d.pub;$("pubout").hidden=false;msg.textContent="Copy the public key and send it to the developer."})}).catch(fail)};
$("rev").onclick=function(){act("admin/block",{block:true},"Blocked")};
$("unrev").onclick=function(){act("admin/block",{block:false},"Allowed again")};
$("rst").onclick=function(){act("admin/reset-devices",{},"Devices reset")};
$("load").onclick=function(){msg.textContent="Loading…";call("admin/purchases",null,"GET").then(function(d){var b=$("tbl").tBodies[0];b.textContent="";(d.purchases||[]).forEach(function(p){var r=b.insertRow();[new Date(p.t).toLocaleString(),p.product,p.cc||"",p.id].forEach(function(v){r.insertCell().textContent=v})});$("tbl").hidden=false;msg.textContent=d.purchases&&d.purchases.length?"":"No purchases recorded yet (or the records store isn't connected)."}).catch(fail)};
</script></main></body></html>`;

export default {
  async fetch(request, env) {
    if (request.method === "OPTIONS") return new Response(null, { status: 204, headers: cors(request) });
    const url = new URL(request.url);
    const path = url.pathname.replace(/^\/api(?=\/)/, "").replace(/\/+$/, "") || "/";
    const ip = request.headers.get("CF-Connecting-IP") || "";
    const net = shortIp(ip);
    const country = request.headers.get("CF-IPCountry") || "";
    try {
      if (request.method === "GET" && path === "/pubkey") return json(request, { pub: (await licenseKeys(env)).pub });
      if (request.method === "GET" && (path === "/" || path === "/status")) return json(request, { ok: true, records: !!env.RECORDS, mode: env.PAYPAL_ENV === "live" ? "live" : "sandbox" });
      if (request.method === "GET" && path === "/config") return json(request, { clientId: env.PAYPAL_CLIENT_ID, mode: env.PAYPAL_ENV === "live" ? "live" : "sandbox" });
      if (request.method === "GET" && path === "/admin") return new Response(ADMIN_PAGE, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "no-store", "X-Robots-Tag": "noindex", "X-Frame-Options": "DENY", "Content-Security-Policy": "default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'", ...SAFE } });

      if (request.method === "GET" && path.indexOf("/download/") === 0) {
        const product = path.slice(10);
        const p = PRODUCTS[product];
        if (!p || !p.file) return json(request, { error: "not found" }, 404);
        const tok = await readDownloadToken(env, url.searchParams.get("t"), product);
        if (!tok) return json(request, { error: "link expired or invalid" }, 403);
        if (!(await hit(env, "rl:dl:" + net, 30, 3600))) return json(request, { error: "too many requests — try again later" }, 429);
        if (!(await paymentOk(env, tok.orderId))) return json(request, { error: "this payment was refunded or reversed" }, 403);
        if (env.RECORDS) {
          const key = "dl:" + tok.orderId + ":" + tok.nonce;
          const rec = (await kget(env, key)) || { n: 0, nets: [] };
          if (rec.n >= MAX_DOWNLOADS) return json(request, { error: "this link has been used too many times — email support@vigilantword.com for a new one" }, 429);
          if (net && rec.nets.indexOf(net) < 0) {
            if (rec.nets.length >= MAX_NETWORKS) return json(request, { error: "this link has been used from too many places — email support@vigilantword.com for a new one" }, 429);
            rec.nets.push(net);
          }
          rec.n++;
          await kput(env, key, rec, tok.expiry - Date.now() / 1000 + 86400);
        }
        if (!env.BOOKS) return json(request, { error: "store not configured" }, 503);
        const object = await env.BOOKS.get(p.file);
        if (!object) return json(request, { error: "file missing" }, 404);
        return new Response(object.body, { headers: { "Content-Type": "application/epub+zip", "Content-Disposition": 'attachment; filename="' + p.file + '"', "Content-Length": String(object.size), "Cache-Control": "private, no-store", ...SAFE } });
      }

      if (request.method === "GET" && path === "/admin/pubkey") {
        const bad = await adminCheck(request, env, net);
        if (bad) return json(request, { error: bad === 429 ? "slow down" : "unauthorized" }, bad);
        return json(request, { pub: (await licenseKeys(env)).pub });
      }

      if (request.method === "GET" && path === "/admin/purchases") {
        const bad = await adminCheck(request, env, net);
        if (bad) return json(request, { error: bad === 429 ? "slow down" : "unauthorized" }, bad);
        const out = [];
        if (env.RECORDS) {
          const list = await env.RECORDS.list({ prefix: "purchase:", limit: 25 });
          for (const k of list.keys) { const v = await kget(env, k.name); if (v) out.push(v); }
        }
        return json(request, { purchases: out });
      }

      if (request.method !== "POST") return env.ASSETS ? env.ASSETS.fetch(request) : json(request, { error: "not found" }, 404);
      if (!originOk(request, url)) return json(request, { error: "forbidden" }, 403);
      const body = await request.json().catch(() => ({}));

      if (path === "/create-order") {
        const p = PRODUCTS[body.product];
        if (!p) return json(request, { error: "unknown product" }, 400);
        if (!(await hit(env, "rl:order:" + net, 20, 3600))) return json(request, { error: "too many requests — try again later" }, 429);
        const r = await fetch(paypalBase(env) + "/v2/checkout/orders", {
          method: "POST",
          headers: { Authorization: "Bearer " + (await accessToken(env)), "Content-Type": "application/json", "PayPal-Request-Id": crypto.randomUUID() },
          body: JSON.stringify({ intent: "CAPTURE", purchase_units: [{ reference_id: body.product, custom_id: body.product, description: p.name, amount: { currency_code: "USD", value: p.price } }] })
        });
        const d = await r.json().catch(() => ({}));
        return r.ok && d.id ? json(request, { id: d.id }) : json(request, { error: "paypal" }, 502);
      }

      if (path === "/capture-order") {
        const { orderID, product } = body;
        if (!PRODUCTS[product] || typeof orderID !== "string" || !/^[A-Za-z0-9]+$/.test(orderID)) return json(request, { error: "bad request" }, 400);
        if (!(await hit(env, "rl:cap:" + net, 20, 3600))) return json(request, { error: "too many requests — try again later" }, 429);
        const auth = { Authorization: "Bearer " + (await accessToken(env)), "Content-Type": "application/json" };
        const base = paypalBase(env) + "/v2/checkout/orders/" + orderID;
        let order;
        const cap = await fetch(base + "/capture", { method: "POST", headers: { ...auth, "PayPal-Request-Id": crypto.randomUUID() } });
        if (cap.ok) order = await cap.json();
        else if (cap.status === 422) order = await (await fetch(base, { headers: auth })).json();
        if (!order || !paidCapture(order, product)) return json(request, { error: "not paid" }, 402);
        if (env.RECORDS && cap.ok) {
          const at = Math.floor(Date.now() / 1000);
          await kput(env, "purchase:" + String(9999999999 - at).padStart(10, "0") + ":" + orderID, { id: orderID, product, t: at * 1000, cc: country, ip: net }, KEEP_PURCHASE);
        }
        return product === "app" ? json(request, { license: await mintLicense(env, "f", orderID) }) : json(request, { token: await makeDownloadToken(env, orderID, product) });
      }

      if (path === "/restore") {
        const id = String(body.id || "").trim();
        if (!/^[A-Za-z0-9]{8,24}$/.test(id)) return json(request, { error: "That doesn't look like a PayPal transaction number." }, 400);
        if (!(await hit(env, "rl:rst:" + net, 10, 3600))) return json(request, { error: "Too many tries. Please wait an hour or email support@vigilantword.com." }, 429);
        const found = await findPayment(env, id);
        if (!found) return json(request, { error: "We couldn't match that number to a completed payment. Check it, or email support@vigilantword.com with your receipt." }, 404);
        return found.product === "app"
          ? json(request, { product: "app", license: await mintLicense(env, "f", found.orderId) })
          : json(request, { product: found.product, token: await makeDownloadToken(env, found.orderId, found.product) });
      }

      if (path === "/license-status") {
        if (!(await hit(env, "rl:ls:" + net, 120, 3600))) return json(request, { valid: true, throttled: true });
        const lic = await readLicense(env, body.token);
        if (!lic) return json(request, { valid: false, reason: "invalid" });
        if (await kget(env, "block:" + lic.id)) return json(request, { valid: false, reason: "blocked" });
        if (lic.t === "f" && !(await paymentOk(env, lic.id))) return json(request, { valid: false, reason: "refunded" });
        const dev = String(body.device || "");
        if (env.RECORDS && /^[A-Za-z0-9-]{8,40}$/.test(dev)) {
          const rec = (await kget(env, "dev:" + lic.id)) || { list: [] };
          if (rec.list.indexOf(dev) < 0) {
            if (rec.list.length >= MAX_DEVICES) return json(request, { valid: false, reason: "devices" });
            rec.list.push(dev);
          }
          await kput(env, "dev:" + lic.id, rec, KEEP_DEVICE);
        }
        return json(request, { valid: true });
      }

      if (path === "/mint" || path === "/admin/block" || path === "/admin/reset-devices" || path === "/admin/pubkey") {
        const bad = await adminCheck(request, env, net);
        if (bad) return json(request, { error: bad === 429 ? "slow down" : "unauthorized" }, bad);
        if (path === "/admin/pubkey") return json(request, { pub: (await licenseKeys(env)).pub });
        if (path === "/mint") {
          const label = String(body.name || "").replace(/[^\w .'-]/g, "").slice(0, 24).trim();
          const id = "G-" + randomId(8);
          const token = await mintLicense(env, "g", id, label);
          return json(request, { id, token, link: APP_URL + "/#unlock=" + token });
        }
        const id = String(body.id || "").trim();
        if (!/^[A-Za-z0-9-]{4,40}$/.test(id)) return json(request, { error: "bad id" }, 400);
        if (path === "/admin/block") {
          if (!env.RECORDS) return json(request, { error: "records store not connected" }, 503);
          if (body.block) await env.RECORDS.put("block:" + id, JSON.stringify({ t: Date.now() })); else await env.RECORDS.delete("block:" + id);
        } else if (env.RECORDS) await env.RECORDS.delete("dev:" + id);
        return json(request, { ok: true });
      }

      return json(request, { error: "not found" }, 404);
    } catch (e) {
      return json(request, { error: "server" }, 500);
    }
  }
};

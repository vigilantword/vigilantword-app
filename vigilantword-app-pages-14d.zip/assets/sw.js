/* Vigilant Word reminder worker: shows scheduled reminder notifications
   and brings the reader back into view when one is tapped. It does not
   intercept fetches or cache the app. */
self.addEventListener('install', function(e){ self.skipWaiting(); });
self.addEventListener('activate', function(e){ e.waitUntil(self.clients.claim()); });
self.addEventListener('notificationclick', function(e){
  e.notification.close();
  var target = (e.notification.data && e.notification.data.view) || 'home';
  e.waitUntil(self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function(list){
    for (var i = 0; i < list.length; i++){
      var c = list[i];
      if ('focus' in c){ c.postMessage({ vigilantWordView: target }); return c.focus(); }
    }
    if (self.clients.openWindow) return self.clients.openWindow('../index.html');
  }));
});
